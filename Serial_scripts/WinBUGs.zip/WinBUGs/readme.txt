
 Script to reproduce information for Appendix Figure 2 & Appendix Table 3 from:

 Cowling BJ, Fang VJ, Riley S, Peiris JS, Leung GM. 
 An estimate of the serial interval of influenza using 
 laboratory-confirmed natural infections in households. 
 Epidemiology, 2009 (in press).

 Last updated by Vicky Fang and Ben Cowling
 Feburary 2, 2009


#1. Set up WinBUGS and R2WinBUGS
#2. Download and upzid WinBUGS.zip to your local computer Drive e.g. C:\\.
#3. Set the working directory at the beginning of the R-scripts e.g. as 'setwd("C:\\WinBUGS\\")'.
#4. Use the R scripts (which call the WinBUGS models in the .bug files).