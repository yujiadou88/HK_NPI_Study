#
# Script to reproduce information for Appendix Figure 2 from:
#
# Cowling BJ, Fang VJ, Riley S, Peiris JS, Leung GM. 
# An estimate of the serial interval of influenza using 
# laboratory-confirmed natural infections in households. 
# Epidemiology, 2009 (in press).
#
# Last updated by Vicky Fang and Ben Cowling
# Feburary 2, 2009

setwd("C:\\WinBUGS\\")

serial <- read.csv("http://web.hku.hk/~bcowling/influenza/Serial_scripts/serial_appendix_table_1.csv", header=TRUE)
source("http://www.hku.hk/bcowling/influenza/Serial_scripts/functions.r")

# I

times <- serial$day_any_symp[!is.na(serial$serial_interval)]
N <- length(times)
truncL <- serial$clinic_day[!is.na(serial$serial_interval)]

data <- list ("N", "times", "truncL")
inits <- function() {
  list (a=runif(1,0,5), 
    b=runif(1,0,10),pi=rbeta(1,1,1))
}
parameters <- c("a", "b", "pi")

serial.sim <- bugs (data, inits, parameters, "serial1.bug",
 n.chains=1, n.iter=2000, n.burnin=500, n.thin=5) 

pi1 <- serial.sim$sims.array[,,"pi"] # beta(1,19)

# II

times <- serial$day_any_symp[!is.na(serial$serial_interval)]
N <- length(times)
truncL <- serial$clinic_day[!is.na(serial$serial_interval)]

data <- list ("N", "times", "truncL")
inits <- function() {
  list (a=runif(1,0,5), 
    b=runif(1,0,10),pi=rbeta(1,1,1))
}
parameters <- c("a", "b", "pi")

serial.sim <- bugs (data, inits, parameters, "serial2.bug",
 n.chains=1, n.iter=2000, n.burnin=500, n.thin=5) 

pi2 <- serial.sim$sims.array[,,"pi"] # beta(2,18)

# III

times <- serial$day_any_symp[!is.na(serial$serial_interval)]
N <- length(times)
truncL <- serial$clinic_day[!is.na(serial$serial_interval)]

data <- list ("N", "times", "truncL")
inits <- function() {
  list (a=runif(1,0,5), 
    b=runif(1,0,10),pi=rbeta(1,1,1))
}
parameters <- c("a", "b", "pi")

serial.sim <- bugs (data, inits, parameters, "serial3.bug",
 n.chains=1, n.iter=2000, n.burnin=500, n.thin=5) 

pi3 <- serial.sim$sims.array[,,"pi"] # beta(3,17)

# IV

times <- serial$day_any_symp[!is.na(serial$serial_interval)]
N <- length(times)
truncL <- serial$clinic_day[!is.na(serial$serial_interval)]

data <- list ("N", "times", "truncL")
inits <- function() {
  list (a=runif(1,0,5), 
    b=runif(1,0,10),pi=rbeta(1,1,1))
}
parameters <- c("a", "b", "pi")

serial.sim <- bugs (data, inits, parameters, "serial4.bug",
 n.chains=1, n.iter=2000, n.burnin=500, n.thin=5) 

pi4 <- serial.sim$sims.array[,,"pi"] # beta(4,16)

#-------------------------plots---------------------------------------------

windows(width=6,height=5)
layout(matrix(1:4,ncol=2,byrow=TRUE))

par(mar=c(3.2,6,1,1))
plot(0, xlim=c(0,0.5), ylim=c(0,20), type="n", xlab="", ylab="", bty="n", axes=FALSE)
hist(pi1, prob=TRUE, col="gray", border=TRUE, add=TRUE)
curve(dbeta(x,1,19), 0, 0.5 , col="blue", add=TRUE, lwd=1.5)
axis(1, pos=0, lwd=1, cex.axis=1.0, at=0:2/4)
axis(2, pos=0, lwd=1, cex.axis=1.0, las=1)
mtext("Density",side=2,cex=1.0,line=2, las=1)
mtext("(a)",side=3,cex=1.0,line=-0.5, las=1)

par(mar=c(3.2,3,1,3))
plot(0, xlim=c(0,0.5), ylim=c(0,20), type="n", xlab="", ylab="", bty="n", axes=FALSE)
hist(pi2, prob=TRUE, col="gray", border=TRUE , add=TRUE)
curve(dbeta(x,2,18), 0, 0.5 , col="blue", add=TRUE, lwd=1.5)
axis(1, pos=0, lwd=1, cex.axis=1.0, at=0:2/4)
axis(2, pos=0, lwd=1, cex.axis=1.0, las=1)
mtext("(b)",side=3,cex=1.0,line=-0.5, las=1)

par(mar=c(3.2,6,1,1))
plot(0, xlim=c(0,0.5), ylim=c(0,20), type="n", xlab="", ylab="", bty="n", axes=FALSE)
hist(pi3, prob=TRUE, col="gray", border=TRUE , add=TRUE)
curve(dbeta(x,3,17), 0, 0.5 , col="blue", add=TRUE, lwd=1.5)
axis(1, pos=0, lwd=1, cex.axis=1.0, at=0:2/4)
axis(2, pos=0, lwd=1, cex.axis=1.0, las=1)
mtext(expression(pi),side=1,cex=1.0,line=2)
mtext("Density",side=2,cex=1.0,line=2, las=1)
mtext("(c)",side=3,cex=1.0,line=-0.5, las=1)

par(mar=c(3.2,3,1,3))
plot(0, xlim=c(0,0.5), ylim=c(0,20), type="n", xlab="", ylab="", bty="n", axes=FALSE)
hist(pi4, prob=TRUE, col="gray", border=TRUE , add=TRUE)
curve(dbeta(x,4,16), 0, 0.5 , col="blue", add=TRUE, lwd=1.5)
axis(1, pos=0, lwd=1, cex.axis=1.0, at=0:2/4)
axis(2, pos=0, lwd=1, cex.axis=1.0, las=1)
mtext(expression(pi),side=1,cex=1.0,line=2)
mtext("(d)",side=3,cex=1.0,line=-0.5, las=1)

# End of script
