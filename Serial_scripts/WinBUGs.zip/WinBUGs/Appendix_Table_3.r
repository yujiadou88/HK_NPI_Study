#
# Script to reproduce information for Appendix Table 3 from:
#
# Cowling BJ, Fang VJ, Riley S, Peiris JS, Leung GM. 
# An estimate of the serial interval of influenza using 
# laboratory-confirmed natural infections in households. 
# Epidemiology, 2009 (in press).
#
# Last updated by Vicky Fang and Ben Cowling
# Feburary 2, 2009

setwd("C:\\WinBUGS\\")
serial <- read.csv("http://web.hku.hk/~bcowling/influenza/Serial_scripts/serial_appendix_table_1.csv", header=TRUE)

appt3 <- matrix(rep(NA,25),ncol=5,byrow=TRUE)

# Original analysis

times <- serial$serial_interval[!is.na(serial$serial_interval)]
N <- length(times)
truncL <- serial$clinic_day[!is.na(serial$serial_interval)]

data <- list ("N", "times", "truncL")
inits <- function() {
  list (a=runif(1,0,5), b=runif(1,0,10))
}
parameters <- c("a", "b")

serial.sim <- bugs (data, inits, parameters, "serial.bug",
 n.chains=1, n.iter=2000, n.burnin=500, n.thin=5) 

appt3[1,3:5] <- c(serial.sim$mean[[1]],serial.sim$mean[[2]],mean(serial.sim$sims.array[,,"b"])*gamma(1+1/mean(serial.sim$sims.array[,,"a"])))

# I

times <- serial$serial_interval[!is.na(serial$serial_interval)]
N <- length(times)
truncL <- serial$clinic_day[!is.na(serial$serial_interval)]

data <- list ("N", "times", "truncL")
inits <- function() {
  list (a=runif(1,0,5), 
    b=runif(1,0,10),pi=rbeta(1,1,1))
}
parameters <- c("a", "b", "pi")

serial.sim <- bugs (data, inits, parameters, "serial1.bug",
 n.chains=1, n.iter=2000, n.burnin=500, n.thin=5) 

appt3[2,2:5] <- round(c(mean(serial.sim$sims.array[,,"pi"]), mean(serial.sim$sims.array[,,"a"]), mean(serial.sim$sims.array[,,"b"]),
		  mean(serial.sim$sims.array[,,"b"])*gamma(1+1/mean(serial.sim$sims.array[,,"a"]))),2)

# II

times <- serial$serial_interval[!is.na(serial$serial_interval)]
N <- length(times)
truncL <- serial$clinic_day[!is.na(serial$serial_interval)]

data <- list ("N", "times", "truncL")
inits <- function() {
  list (a=runif(1,0,5), 
    b=runif(1,0,10),pi=rbeta(1,1,1))
}
parameters <- c("a", "b", "pi")

serial.sim <- bugs (data, inits, parameters, "serial2.bug",
 n.chains=1, n.iter=2000, n.burnin=500, n.thin=5) 

appt3[3,2:5] <- round(c(mean(serial.sim$sims.array[,,"pi"]), mean(serial.sim$sims.array[,,"a"]), mean(serial.sim$sims.array[,,"b"]),
		  mean(serial.sim$sims.array[,,"b"])*gamma(1+1/mean(serial.sim$sims.array[,,"a"]))),2)

# III

times <- serial$serial_interval[!is.na(serial$serial_interval)]
N <- length(times)
truncL <- serial$clinic_day[!is.na(serial$serial_interval)]

data <- list ("N", "times", "truncL")
inits <- function() {
  list (a=runif(1,0,5), 
    b=runif(1,0,10),pi=rbeta(1,1,1))
}
parameters <- c("a", "b", "pi")

serial.sim <- bugs (data, inits, parameters, "serial3.bug",
 n.chains=1, n.iter=2000, n.burnin=500, n.thin=5) 

appt3[4,2:5] <- round(c(mean(serial.sim$sims.array[,,"pi"]), mean(serial.sim$sims.array[,,"a"]), mean(serial.sim$sims.array[,,"b"]),
		  mean(serial.sim$sims.array[,,"b"])*gamma(1+1/mean(serial.sim$sims.array[,,"a"]))),2)

# IV

times <- serial$serial_interval[!is.na(serial$serial_interval)]
N <- length(times)
truncL <- serial$clinic_day[!is.na(serial$serial_interval)]

data <- list ("N", "times", "truncL")
inits <- function() {
  list (a=runif(1,0,5), 
    b=runif(1,0,10),pi=rbeta(1,1,1))
}
parameters <- c("a", "b", "pi")

serial.sim <- bugs (data, inits, parameters, "serial4.bug",
 n.chains=1, n.iter=2000, n.burnin=500, n.thin=5) 

appt3[5,2:5] <- round(c(mean(serial.sim$sims.array[,,"pi"]), mean(serial.sim$sims.array[,,"a"]), mean(serial.sim$sims.array[,,"b"]),
		  mean(serial.sim$sims.array[,,"b"])*gamma(1+1/mean(serial.sim$sims.array[,,"a"]))),2)

appt3[2:5,1] <- 1:4/20

rownames(appt3) <- c("Original","I","II","III","IV")
colnames(appt3) <- c("prior","posterior","a","b","mean")
appt3

# End of script

